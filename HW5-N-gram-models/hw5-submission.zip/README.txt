Just run 
python3 language_model.py
For constrained results
ner_igacio.py ner_igacio.ipynb

For unconstrained results:
LSTM-CRF is in (word_layer.mat in model/spanish.005 is 20MB and is ignored)
tagger/ner_LSTM.py tagger/ner_LSTM.ipynb (you only need to run one of the two)
with supporting folder tagger/

(Only) CRF is in
ner_crf.py ner_crf.ipynb 



